#include<stdio.h>
#include<stdlib.h>
void main()
{
	printf("Inline Assembly\n");
/*	asm("movl $1,%eax\n\tmovl $0,%ebx\n\tint $0x80");*/
exit(0);
}
